create definer = root@localhost trigger CreateUserTableList
    after insert
    on users
    for each row
    INSERT INTO `userTableList` (`userID`) VALUES (NEW.userID);

