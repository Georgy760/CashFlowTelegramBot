create definer = root@localhost trigger InsertTableNewBanker
    after insert
    on tables
    for each row
    IF (NEW.`tableType` = 'copper' AND NEW.bankerID) THEN
	UPDATE `userTableList` SET `userTableList`.`table_ID_copper` = NEW.`tableID` WHERE `userTableList`.`userID` = NEW.bankerID;

ELSEIF (NEW.`tableType` = 'bronze' AND NEW.bankerID) THEN
	UPDATE `userTableList` SET `userTableList`.`table_ID_bronze` = NEW.`tableID` WHERE `userTableList`.`userID` = NEW.bankerID;

ELSEIF (NEW.`tableType` = 'silver' AND NEW.bankerID) THEN
	UPDATE `userTableList` SET `userTableList`.`table_ID_silver` = NEW.`tableID` WHERE `userTableList`.`userID` = NEW.bankerID;

ELSEIF (NEW.`tableType` = 'gold' AND NEW.bankerID) THEN
	UPDATE `userTableList` SET `userTableList`.`table_ID_gold` = NEW.`tableID` WHERE `userTableList`.`userID` = NEW.bankerID;

ELSEIF (NEW.`tableType` = 'platinum' AND NEW.bankerID) THEN
	UPDATE `userTableList` SET `userTableList`.`table_ID_platinum` = NEW.`tableID` WHERE `userTableList`.`userID` = NEW.bankerID;

ELSEIF (NEW.`tableType` = 'diamond' AND NEW.bankerID) THEN
	UPDATE `userTableList` SET `userTableList`.`table_ID_diamond` = NEW.`tableID` WHERE `userTableList`.`userID` = NEW.bankerID;
END IF;

